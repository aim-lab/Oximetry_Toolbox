OverallGeneralMeasures module
=============================

.. automodule:: OverallGeneralMeasures
    :members:
    :undoc-members:
    :show-inheritance:
