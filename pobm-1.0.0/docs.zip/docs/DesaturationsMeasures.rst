DesaturationsMeasures module
============================

.. automodule:: DesaturationsMeasures
    :members:
    :undoc-members:
    :show-inheritance:
